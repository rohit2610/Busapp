package com.example.busapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.Window;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.Calendar;
import java.util.Date;

public class TimeTable extends AppCompatActivity {

    FirebaseDatabase database ;
    DatabaseReference rootReference ;
    DatabaseReference childReference ;
    FirebaseFirestore db = FirebaseFirestore.getInstance();



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_table);

        Date time = Calendar.getInstance().getTime();
        Log.i("TIme",time.toString()) ;

        database = FirebaseDatabase.getInstance();

        //childReference = database.getReference();

        //writeNewTimings("28/5/10","17:00");

        db.collection("BusTimings")
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if(! task.isSuccessful()){
                            Log.i("Task," ,"failed");
                        }

                        else
                        {
                         for (QueryDocumentSnapshot documentSnapshot :task.getResult()){
                            Log.i("Task",documentSnapshot.toString());
                         }
                    }
                }});



        /*myRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                Timings date = dataSnapshot.getValue(Timings.class);
                Log.i("Time",date.getTime());
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Log.i("Error",databaseError.toString());
            }
        });*/
    }

    public void writeNewTimings(String date, String time){
        Timings t = new Timings(time,date);
        childReference.child("Timings").setValue(t);
    }

    public class Timings{

        public String time;
        public String day ;

        public Timings(){

        }

        public Timings(String time , String day){
            this.day = day;
            this.time = time;
        }

        public String getTime(){
            return time ;
        }


    }
}


